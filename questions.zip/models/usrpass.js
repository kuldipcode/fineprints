const mongoose = require('mongoose')

const userpassSchema = mongoose.Schema({
    user:String,
    password:String
})

const userpass = mongoose.model('Userpass',userpassSchema);

module.exports = userpass;