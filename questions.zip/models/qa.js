const mongoose = require('mongoose');

const autherSchema = new mongoose.Schema({auther:'string'});

const questionSchema = new mongoose.Schema({
    question:String,
    answer:String,
    catagory:String,
    level:String,    
    createdAt: {
        type: Date,
        default: Date.now
    },
    auther:[autherSchema]
});

const question = mongoose.model('Question',questionSchema);
module.exports = question;