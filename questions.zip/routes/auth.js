const user = require('../models/usrpass')
const auth = (req,res,next)=>{   
    const authh = {login:"",password:""}
    console.log(req.headers.authorization)
    const b64auth = req.headers.authorization.split(" ")[1]
    const [login,password] = Buffer.from(b64auth,'base64').toString().split(':')
    
    user.findOne({user:login}).then(data=>{
        authh.login = data.user;
        authh.password = data.password;
        if (login && password && login===authh.login && password === authh.password){
            console.log("access granted")
            return next()
        }
        res.status(401).send("Authentication Required !")
    }).catch(err =>{ console.log(err)})   
    
}
module.exports = auth;