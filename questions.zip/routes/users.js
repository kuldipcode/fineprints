const express = require('express');
const user = require('../models/usrpass')
const router = express.Router();

router.post('/',(req, res)=>{
    
    const b64auth = req.headers.authorization.split(" ")[1]
    const userPass = Buffer.from(b64auth,'base64').toString().split(":");
    const User = new user({user:userPass[0],password:userPass[1]});
    User.save((err,data)=>{
        if (err) return console.log(err);

        res.status(200).send(data+"saved successfully");
    })
    console.log(userPass)    
})

router.get('/y',(req, res)=>{
    res.send({})
})

module.exports = router;