const express = require('express');
const qa = require('../models/qa')
const auth = require('./auth')
const router = express.Router();

router.get('/pub',(req, res)=>{  
    qa.find({},{"_id":0,"question":1,"auther.auther":1}).then(data=>{
        res.json(data)
    }).catch(err=>{
        console.log(err)
    })  
})

router.post('/pub',(req, res)=>{
    
    const x = {question:req.body.question,answer:req.body.answer,catagory:req.body.catagory,level:req.body.level,auther: [{auther:req.body.auther}]}
    console.log(x)
    const questions = new qa(x);
    
    questions.save(function(err,data){        
        if(err) return console.log(err);
            
    res.status(200).send(JSON.stringify(x)+"saved successfully")
    })    
})

router.get('/moderator',auth, (req, res)=>{  
    qa.find({},{"_id":0,"question":1,"answer":1,"auther.auther":1}).then(data=>{
        res.json(data)
    }).catch(err=>{
        console.log(err)
    })  
})

router.put('/moderator',auth,(req, res)=>{
    
    const x = {question:req.body.question,answer:req.body.answer,catagory:req.body.catagory,level:req.body.level,auther: [{auther:req.body.auther}]}
    console.log(x)
    qa.updateMany({question: x.question}, {$set: {level:x.level}})          
    res.status(200).send(JSON.stringify(x)+"saved successfully")
    })    

router.delete('/moderator',auth,(req, res)=>{
    qa.deleteMany({}).then(data=>{
        res.json(data)
    }).catch(err=>{
        console.log(err)
    })
})  

module.exports = router;