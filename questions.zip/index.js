const express = require('express')
const bodyParser = require('body-parser')
const cors = require('cors')
const qa = require('./routes/qa')
const users = require('./routes/users')
const mongoose = require('mongoose')
const app = express()
const port = 3000

mongoose.connect('mongodb://localhost/test',{useNewUrlParser: true, useUnifiedTopology: true})
const db = mongoose.connection;
db.on('error', console.error.bind(console,"Connection error"));
db.once('open',()=>{console.log("connected !")})
app.use(cors())
app.use(bodyParser.json())
app.use('/questions',qa)
app.use('/signup',users)

app.listen(port,()=>{
    console.log(`listening at http://localhost:${port}`)
})