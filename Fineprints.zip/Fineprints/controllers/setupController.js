var Insurance = require('../models/insuranceModel');

module.exports = function(app) {
    
   app.get('/api/setupInsurance', function(req, res) {
       
       // seed database
       var starterInsurance = [
           {
               company: 'Geico',
               fineprint: 'Content1',
               rate: '50',
               deductible: '10',
               
           },
           {
               company: 'American Insurance',
               fineprint: 'Content2',
               rate: '50',
               deductible: '10',
            },
           {
               company: 'Enterprise',
               fineprint: 'Content3',
               rate: '50',
               deductible: '10',
           }
       ];
       Insurance.create(starterInsurance, function(err, results) {
           res.send(results);
       }); 
   });
    
}