var Insurance = require('../models/insuranceModel');
var bodyParser = require('body-parser');

module.exports = function(app) {
    
    app.use(bodyParser.json());
    app.use(bodyParser.urlencoded({ extended: true }));
    
    app.get('/api/carinsurance', function(req, res) {
        
        Insurance.find({}, function(err, insurance) {
            if (err) throw err;
            
            res.send(insurance);
        });
        
    });
    
    // app.get('/api/insurance/:id', function(req, res) {
       
    //    Insurance.findById({ _id: req.params.id }, function(err, insurance) {
    //        if (err) throw err;
           
    //        res.send(insurance);
    //    });
        
    // });
    
    app.post('/api/carinsurance', function(req, res) {
        
        if (req.body.id) {
            Insurance.findByIdAndUpdate(req.body.id, { company: req.body.company, fineprint: req.body.fineprint, rate: req.body.rate, deductible: req.body.deductible, hasAttachment: req.body.hasAttachment }, function(err, insurance) {
                if (err) throw err;
                
                res.send(insurance);
            });
        }
        
        else {
           
           var newinsurance = Insurance({
               company: req.body.company, 
               fineprint: req.body.fineprint, 
               rate: req.body.rate, 
               deductible: req.body.deductible, 
               file: req.body.file
           });
           newinsurance.save(function(err, insurance) {
               if (err) throw err;
               res.send(insurance);
           });
            
        }
        
    });
    
    // app.delete('/api/insurance', function(req, res) {
        
    //     Insurance.findByIdAndRemove(req.body.id, function(err) {
    //         if (err) throw err;
    //         res.send('Success');
    //     })
        
    // });
    
}