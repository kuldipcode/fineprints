In root directory run following command
node app.js

click following link
http://localhost:3000

