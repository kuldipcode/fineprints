"use strict";
var Insurance = (function () {
    function Insurance() {
    }
    return Insurance;
}());
exports.Insurance = Insurance;
//# sourceMappingURL=insurance.js.map