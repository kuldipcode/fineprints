export class Insurance  {
  _id: string;
  company: String;
  fineprint: String;
  rate: String;
  deductible:String;
  file?: string  
}