import { Component } from '@angular/core';
import { Insurance } from './insurance';
import { InsuranceService } from './insurance.service';
@Component({
  template: `<div class="result"><h1>Comparisons !</h1>
  
    <p-dataTable  [value]="insurance">
        <p-column field="company" header="company" [sortable]="true"></p-column>
        <p-column field="fineprint" header="fineprint" [sortable]="true"></p-column>
        <p-column field="rate" header="rate" [sortable]="true"></p-column>
        <p-column field="deductible" header="deductible" [sortable]="true"></p-column>
  </p-dataTable></div>`,
  providers: [ InsuranceService ]
})


export class AppComponent  { 
  insurance: Insurance[];
  constructor(private insuranceService: InsuranceService) { insuranceService.insuranceApiUrl = '/api/carinsurance';}
  getInsurance(): void {
    this.insuranceService.getInsurance().then(insurance => this.insurance = insurance);
    
  }
  ngOnInit(): void {
    
    this.getInsurance();  
      
  }
}
