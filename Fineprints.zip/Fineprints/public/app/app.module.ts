import { NgModule }      from '@angular/core';
import { HttpModule }    from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import {DataTableModule,SharedModule} from 'primeng/primeng';
import { FormsModule }   from '@angular/forms';
import { AppComponent }  from './app.component';
import { FineprintAppComponent}    from './fineprint-app.component';
import { CarFormComponent}    from './carForm.component';
import {RouterModule, Routes} from '@angular/router';

const routes:Routes = [{path:'result', component: AppComponent},
                       {path:'carForm',component :CarFormComponent},
                       {path:'lifeForm',component :AppComponent}
                       
];
@NgModule({
  imports:      [ BrowserModule, HttpModule,FormsModule, DataTableModule, SharedModule, RouterModule.forRoot(routes)],
  declarations: [ AppComponent,FineprintAppComponent,CarFormComponent],
  bootstrap:    [ FineprintAppComponent ]
})
export class AppModule { }
