import { Injectable } from '@angular/core';
import { Headers, Http } from '@angular/http';

import 'rxjs/add/operator/toPromise';

import { Insurance } from './insurance';

@Injectable()
export class InsuranceService {
  
  private headers = new Headers({'Content-Type': 'application/json'});
  public insuranceApiUrl = '/api/getInsurance';
  
  constructor(private http: Http) { }
    
  getInsurance(): Promise<Insurance[]> {
    return this.http.get(this.insuranceApiUrl)
               .toPromise()
               .then(response => response.json() as Insurance[])
  }

  postInsurance(_id: string, company: String, fineprint: String, rate: String,deductible:String,file?: string): Promise<Text> {
  return this.http
    .post(this.insuranceApiUrl,{_id:_id,company:company,fineprint:fineprint,rate:rate,deductible:deductible}, {headers: this.headers})
    .toPromise()
    .then(response => response.json())
    .catch(this.handleError);
}
private handleError(error: any): Promise<any> {
  console.error('An error occurred', error); // for demo purposes only
  return Promise.reject(error.message || error);
}
}