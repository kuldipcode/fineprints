"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var insurance_service_1 = require('./insurance.service');
var insurance_1 = require('./insurance');
var CarFormComponent = (function () {
    function CarFormComponent(insuranceService) {
        this.insuranceService = insuranceService;
        this.insurance = {
            _id: 'abc',
            company: 'xd',
            fineprint: 'ff',
            rate: 'dff',
            deductible: 'klnjf',
            file: ''
        };
        insuranceService.insuranceApiUrl = '/api/carinsurance';
    }
    CarFormComponent.prototype.save = function () {
        console.log("***********" + this.insurance.file);
        this.insuranceService.postInsurance(this.insurance._id, this.insurance.company, this.insurance.fineprint, this.insurance.rate, this.insurance.deductible, this.insurance.file);
        //.postInsurance(this.insurance);   
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', insurance_1.Insurance)
    ], CarFormComponent.prototype, "insurance", void 0);
    CarFormComponent = __decorate([
        core_1.Component({
            templateUrl: './app/carForm.component.html',
            providers: [insurance_service_1.InsuranceService]
        }), 
        __metadata('design:paramtypes', [insurance_service_1.InsuranceService])
    ], CarFormComponent);
    return CarFormComponent;
}());
exports.CarFormComponent = CarFormComponent;
//# sourceMappingURL=carForm.component.js.map