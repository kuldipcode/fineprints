"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var insurance_service_1 = require('./insurance.service');
var AppComponent = (function () {
    function AppComponent(insuranceService) {
        this.insuranceService = insuranceService;
        insuranceService.insuranceApiUrl = '/api/carinsurance';
    }
    AppComponent.prototype.getInsurance = function () {
        var _this = this;
        this.insuranceService.getInsurance().then(function (insurance) { return _this.insurance = insurance; });
    };
    AppComponent.prototype.ngOnInit = function () {
        this.getInsurance();
    };
    AppComponent = __decorate([
        core_1.Component({
            template: "<div class=\"result\"><h1>Comparisons !</h1>\n  \n    <p-dataTable  [value]=\"insurance\">\n        <p-column field=\"company\" header=\"company\" [sortable]=\"true\"></p-column>\n        <p-column field=\"fineprint\" header=\"fineprint\" [sortable]=\"true\"></p-column>\n        <p-column field=\"rate\" header=\"rate\" [sortable]=\"true\"></p-column>\n        <p-column field=\"deductible\" header=\"deductible\" [sortable]=\"true\"></p-column>\n  </p-dataTable></div>",
            providers: [insurance_service_1.InsuranceService]
        }), 
        __metadata('design:paramtypes', [insurance_service_1.InsuranceService])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map