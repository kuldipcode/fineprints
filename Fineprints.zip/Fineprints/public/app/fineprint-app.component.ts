import {Component} from '@angular/core';

@Component({
selector:'my-app',
template:'<h1 class="logo">FinePrint Comparison Tool</h1><button class="btn btn-success"routerLink = "/carForm">UPLOAD CAR INSURANCE DETAILS</button><br><br><button class="btn btn-success" routerLink = "/result">COMPARISON</button><br><router-outlet></router-outlet>'
})

export class FineprintAppComponent{}