import { Component, Input } from '@angular/core';
import { InsuranceService } from './insurance.service';
import {Insurance} from './insurance';
@Component({
  templateUrl: './app/carForm.component.html',
  providers: [ InsuranceService ]
})
export class CarFormComponent {

@Input() insurance : Insurance = {
  _id: 'abc',
  company: 'xd',
  fineprint: 'ff',
  rate: 'dff',
  deductible:'klnjf',
  file:''
};

constructor(private insuranceService: InsuranceService) { insuranceService.insuranceApiUrl = '/api/carinsurance';}
save(): void {

  console.log("***********"+this.insurance.file);
   
  this.insuranceService.postInsurance(this.insurance._id,this.insurance.company,this.insurance.fineprint,this.insurance.rate,this.insurance.deductible,
  this.insurance.file)
  //.postInsurance(this.insurance);   

}
 
  // model = new CarForm('Geico', 'Dr IQ', 'bkjb', 'Chuck Overstreet','hjhb');

  // submitted = false;

  // onSubmit() { this.submitted = true; }

  // // TODO: Remove this when we're done
  // get diagnostic() { return JSON.stringify(this.model); }
  
}
