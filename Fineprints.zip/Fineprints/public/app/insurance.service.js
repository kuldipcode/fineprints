"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
require('rxjs/add/operator/toPromise');
var InsuranceService = (function () {
    function InsuranceService(http) {
        this.http = http;
        this.headers = new http_1.Headers({ 'Content-Type': 'application/json' });
        this.insuranceApiUrl = '/api/getInsurance';
    }
    InsuranceService.prototype.getInsurance = function () {
        return this.http.get(this.insuranceApiUrl)
            .toPromise()
            .then(function (response) { return response.json(); });
    };
    InsuranceService.prototype.postInsurance = function (_id, company, fineprint, rate, deductible, file) {
        return this.http
            .post(this.insuranceApiUrl, { _id: _id, company: company, fineprint: fineprint, rate: rate, deductible: deductible }, { headers: this.headers })
            .toPromise()
            .then(function (response) { return response.json(); })
            .catch(this.handleError);
    };
    InsuranceService.prototype.handleError = function (error) {
        console.error('An error occurred', error); // for demo purposes only
        return Promise.reject(error.message || error);
    };
    InsuranceService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http])
    ], InsuranceService);
    return InsuranceService;
}());
exports.InsuranceService = InsuranceService;
//# sourceMappingURL=insurance.service.js.map