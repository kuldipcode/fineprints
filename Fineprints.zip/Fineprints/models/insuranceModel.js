var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var insuranceSchema = new Schema({
    company: String,
    fineprint: String,
    rate: String,
    deductible: String,
    file:Object
    
});

var Insurance = mongoose.model('Insurance', insuranceSchema);

module.exports = Insurance;